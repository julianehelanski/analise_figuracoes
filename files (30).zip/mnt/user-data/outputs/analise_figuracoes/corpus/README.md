# Corpus

Este diretório contém a documentação do corpus de obras analisadas e o texto extraído dos PDFs. **Os PDFs originais permanecem no Google Drive privado da pesquisadora**, sincronizados localmente via Google Drive for Desktop, e **não são distribuídos por este repositório**.

## Estrutura

```
corpus/
├── README.md           # este arquivo
├── txt/                # texto extraído via pdftotext (commitado)
└── metadata.csv        # metadados das obras (commitado)
```

**Não há pasta `pdf/` neste repositório.** Os PDFs ficam em pasta sincronizada do Drive, e o caminho local é informado pela variável `CORPUS_PDF_PATH` no arquivo `.env` (não versionado). Ver `README.md` da raiz para instruções de configuração.

## Como os PDFs são acessados

1. Os PDFs estão armazenados em uma pasta privada do Google Drive da pesquisadora.
2. A pasta é sincronizada localmente via Google Drive for Desktop.
3. O caminho local da pasta sincronizada é registrado em `.env` (raiz do repositório).
4. Os scripts do pipeline leem os PDFs diretamente desse caminho.
5. O texto extraído (output do `pdftotext -layout`) é salvo em `corpus/txt/` e versionado.

Esta configuração tem três vantagens:
- **Conformidade legal**: PDFs sob copyright permanecem em armazenamento pessoal, não em plataforma pública.
- **Reprodutibilidade**: outras pesquisadoras adquirem os PDFs por seus próprios canais e apontam o `.env` delas para a pasta delas.
- **Trabalho em múltiplas máquinas**: cada máquina tem seu `.env` apontando para o caminho local sincronizado.

## Obras esperadas

Os PDFs na pasta do Drive devem ser nomeados conforme o padrão `<autor>_<ano>_<titulo-curto>.pdf`, em minúsculas, sem acentos nem espaços. O script `01_extract_text.py` lê o `CORPUS_PDF_PATH`, lista os arquivos presentes, cruza com a tabela abaixo, e reporta quais obras esperadas faltam.

### Latour

| ID | Arquivo | Obra | Ano | Idioma |
|----|---------|------|-----|--------|
| L1 | `latour_1984_pasteur.pdf` | *Pasteur: guerre et paix des microbes* | 1984 | francês |
| L2 | `latour_1987_science_in_action.pdf` | *Science in Action* | 1987 | inglês |
| L3 | `latour_1996_clarifications.pdf` | *On actor-network theory: a few clarifications* | 1996 | inglês |
| L4 | `latour_1999_pandoras_hope.pdf` | *Pandora's Hope* | 1999 | inglês |
| L5 | `latour_1999_recalling_ant.pdf` | *On recalling ANT* | 1999 | inglês |
| L6 | `latour_2005_reassembling.pdf` | *Reassembling the Social* | 2005 | inglês |

### Haraway

| ID | Arquivo | Obra | Ano | Idioma |
|----|---------|------|-----|--------|
| H1 | `haraway_1985_cyborg_manifesto.pdf` | *A Cyborg Manifesto* | 1985 | inglês |
| H2 | `haraway_1988_situated_knowledges.pdf` | *Situated Knowledges* | 1988 | inglês |
| H3 | `haraway_1992_promises_of_monsters.pdf` | *The Promises of Monsters* | 1992 | inglês |
| H4 | `haraway_1997_modest_witness.pdf` | *Modest_Witness@Second_Millennium* | 1997 | inglês |
| H5 | `haraway_2003_companion_species.pdf` | *The Companion Species Manifesto* | 2003 | inglês |
| H6 | `haraway_2008_when_species_meet.pdf` | *When Species Meet* | 2008 | inglês |
| H7 | `haraway_2016_staying_with_trouble.pdf` | *Staying with the Trouble* | 2016 | inglês |
| H7b | `haraway_2023_ficar_com_problema.pdf` | *Ficar com o problema* (tradução n-1) | 2023 | português |

### Stengers (corpus reduzido)

| ID | Arquivo | Obra | Ano | Idioma |
|----|---------|------|-----|--------|
| S1 | `stengers_2005_cosmopolitical_proposal.pdf` | *The Cosmopolitical Proposal* | 2005 | inglês |
| S2 | `stengers_2010_cosmopolitics_1.pdf` | *Cosmopolitics I* | 2010 | inglês |

### Ingold (corpus reduzido)

| ID | Arquivo | Obra | Ano | Idioma |
|----|---------|------|-----|--------|
| I1 | `ingold_2011_being_alive.pdf` | *Being Alive* | 2011 | inglês |
| I2 | `ingold_2015_life_of_lines.pdf` | *The Life of Lines* | 2015 | inglês |

## Metadados

O arquivo `metadata.csv` é gerado/atualizado pela Etapa 0 e contém:

```
id, autor, titulo, ano, idioma, edicao, paginas_total,
pagina_inicio_corpo, pagina_fim_corpo, palavras_corpo, qualidade_extracao
```

## Critérios de qualidade da extração

- `excelente`: texto limpo, sem quebras absurdas, palavras inteiras, caracteres especiais corretos.
- `aceitavel`: pequenos problemas (palavras hifenizadas mal separadas, alguns caracteres especiais), corrigíveis posteriormente.
- `ruim`: quebras frequentes, muitas palavras coladas, caracteres corrompidos. Considerar OCR com tesseract.

## Observação sobre traduções

Sempre que possível, trabalho com originais. Traduções brasileiras de Latour e Haraway entram como camada adicional de análise, não como substituto. Quando uma obra é processada em mais de um idioma, recebe sufixo no ID (ex.: `H7` para original, `H7b` para tradução brasileira), e o cruzamento entre versões é feito explicitamente, com `idioma` como coluna obrigatória nos CSVs de saída.

## Solução de problemas

**A pasta `CORPUS_PDF_PATH` está vazia ou inexistente**

1. Verifique se o Google Drive for Desktop está em execução (ícone na barra de tarefas / barra de menu).
2. Verifique se a sincronização da pasta `analise_figuracoes_corpus` está ativada e não pausada.
3. Verifique se o caminho em `.env` corresponde ao caminho local real após sincronização (em macOS, costuma ter `/Library/CloudStorage/GoogleDrive-<email>/My Drive/...`).
4. Se a pasta está sincronizada mas vazia, verifique no Drive web se os PDFs estão lá.

**Erro de permissão ao acessar a pasta**

- Verifique que sua conta de usuário tem permissão de leitura na pasta.
- Em macOS, pode ser necessário conceder acesso a Disco Completo (Full Disk Access) ao terminal nas Preferências do Sistema → Privacidade e Segurança.

**O PDF está corrompido ou não abre**

- Tente baixar novamente do Drive web e substituir o arquivo local.
- Se mesmo assim falhar, marque qualidade como `ruim` no `metadata.csv` e considere OCR com tesseract.
